<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>WEB ESCOLA</title>

    <!-- Bootstrap -->
    <link rel="stylesheet" href="bootstrap-5.0.2-dist/css/bootstrap.min.css">

    <!-- Datatable -->
    <link rel="stylesheet" href="bootstrap-5.0.2-dist/css/dataTables.bootstrap5.min.css">

</head>

<body>