    <!-- Bootstrap JavaScript -->
    <script src="bootstrap-5.0.2-dist/js/bootstrap.bundle.min.js"></script>

    <script src="bootstrap-5.0.2-dist/js/dt/jquery-3.7.0.js"></script>
    <script src="bootstrap-5.0.2-dist/js/dt/jquery.dataTables.min.js"></script>
    <script src="bootstrap-5.0.2-dist/js/dt/dataTables.bootstrap5.min.js"></script>
    <script src="bootstrap-5.0.2-dist/js/dt/datatable.js"></script>

    </body>

    </html>