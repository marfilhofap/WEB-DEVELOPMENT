new DataTable('#dt_materia');
new DataTable('#dt_utilijador');
new DataTable('#dt_aula');
new DataTable('#dt_estudante');
